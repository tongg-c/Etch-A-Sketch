let drawBoolean = true;
let eraseBoolean = false;
let gridColumns = 50;

const grid = document.querySelector('.grid');
const slider = document.querySelector('input[type="range"]');
const rangeLabel = document.querySelector('#rangeLabel');
const erase = document.querySelector('#erase');

function createGrid() {
    grid.innerHTML = '';
    grid.style.gridTemplateColumns = `repeat(${slider.value}, 1fr)`;
    for(let i = 0; i < slider.value * slider.value; i++){
        const gridElement = document.createElement('div')
        gridElement.classList.add('grid-element')
        gridElement.addEventListener('mousedown', mouseDown);
        window.addEventListener('mouseup', mouseUp);
        grid.appendChild(gridElement)
    }
}
createGrid();
rangeLabel.textContent = slider.value +'x' + slider.value;
slider.addEventListener('input', () => {
    rangeLabel.textContent = slider.value +'x' + slider.value;
    createGrid();
});

function getCurrentColor() {
    return document.querySelector('#color').value;
};

//draws on etch-a-sketch grid only when mouse is down 
function mouseDown(e) {
    const color = document.querySelector('#color').value;
    if(drawBoolean === true){
        e.target.style.backgroundColor = getCurrentColor();
    } else {
        e.target.style.backgroundColor = 'white'
    }
    const gridElements = document.querySelectorAll('.grid-element');
    gridElements.forEach((element) => {
        element.addEventListener('mouseenter', mouseEnter);
    });
};
// allows mouse drags to draw on board
function mouseEnter(e) {
    const color = document.querySelector('#color').value;
    if(drawBoolean === true){
        e.target.style.backgroundColor = color;
    } else {
        e.target.style.backgroundColor = 'white'
    }
};
//removes 'mouseenter' event when mouse is up
function mouseUp() {
    const gridElements = document.querySelectorAll('.grid-element');
    gridElements.forEach((element) => {
        element.removeEventListener('mouseenter', mouseEnter)
    });
};

const draw = document.querySelector('#draw');
draw.style.backgroundColor = 'pink'
draw.addEventListener('click', () => {
    drawBoolean = true;
    eraseBoolean = false;
    draw.style.backgroundColor = 'pink'
    erase.style.backgroundColor = 'white'
});
erase.addEventListener('click', () => {
    drawBoolean = false;
    eraseBoolean = true;
    draw.style.backgroundColor = 'white'
    erase.style.backgroundColor = 'pink'
});

//resets etch-a-sketch grid when button is clicked
const reset = document.querySelector('#reset');
reset.addEventListener('click', () => {
    createGrid();
});








